---
name: Quiet Heritage Atelier
colors:
  surface: '#fff8f6'
  surface-dim: '#e8d6d1'
  surface-bright: '#fff8f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff1ed'
  surface-container: '#fdeae5'
  surface-container-high: '#f7e4df'
  surface-container-highest: '#f1dfd9'
  on-surface: '#231917'
  on-surface-variant: '#524341'
  inverse-surface: '#392e2b'
  inverse-on-surface: '#ffede8'
  outline: '#847370'
  outline-variant: '#d7c2be'
  surface-tint: '#855047'
  primary: '#824e45'
  on-primary: '#ffffff'
  primary-container: '#9f665c'
  on-primary-container: '#fffbff'
  inverse-primary: '#fab6a9'
  secondary: '#685c50'
  on-secondary: '#ffffff'
  secondary-container: '#f1e0cf'
  on-secondary-container: '#6f6255'
  tertiary: '#5d5c58'
  on-tertiary: '#ffffff'
  tertiary-container: '#767471'
  on-tertiary-container: '#fbffe4'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad4'
  primary-fixed-dim: '#fab6a9'
  on-primary-fixed: '#351009'
  on-primary-fixed-variant: '#693a31'
  secondary-fixed: '#f1e0cf'
  secondary-fixed-dim: '#d4c4b4'
  on-secondary-fixed: '#231a10'
  on-secondary-fixed-variant: '#504539'
  tertiary-fixed: '#e5e2dd'
  tertiary-fixed-dim: '#c8c6c2'
  on-tertiary-fixed: '#1c1c19'
  on-tertiary-fixed-variant: '#474743'
  background: '#fff8f6'
  on-background: '#231917'
  surface-variant: '#f1dfd9'
typography:
  display-lg:
    fontFamily: EB Garamond
    fontSize: 3.5rem
    fontWeight: '400'
    lineHeight: '1.15'
    letterSpacing: 0.02em
  display-lg-mobile:
    fontFamily: EB Garamond
    fontSize: 2.25rem
    fontWeight: '400'
    lineHeight: '1.2'
    letterSpacing: 0.02em
  headline-lg:
    fontFamily: EB Garamond
    fontSize: 2.5rem
    fontWeight: '400'
    lineHeight: '1.25'
    letterSpacing: 0.015em
  headline-lg-mobile:
    fontFamily: EB Garamond
    fontSize: 1.75rem
    fontWeight: '400'
    lineHeight: '1.3'
    letterSpacing: 0.015em
  headline-md:
    fontFamily: EB Garamond
    fontSize: 1.75rem
    fontWeight: '400'
    lineHeight: '1.35'
    letterSpacing: 0.01em
  headline-sm:
    fontFamily: EB Garamond
    fontSize: 1.25rem
    fontWeight: '400'
    lineHeight: '1.4'
    letterSpacing: 0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '300'
    lineHeight: '1.7'
    letterSpacing: -0.01em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.9375rem
    fontWeight: '400'
    lineHeight: '1.65'
    letterSpacing: 0em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.15em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.6875rem
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.12em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.625rem
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 2rem
  gutter-mobile: 1rem
  margin: 4rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system embodies quiet luxury, classical restraint, and the timeless romance of bespoke Indian fine jewellery. It prioritizes deliberate poise over loud ornamentation, balancing the historical depth of heritage craftsmanship with the sleek, airy discipline of high-end editorial curation.

The aesthetic fuses minimalism with tactile editorial layouts: generous negative space, featherlight hairline borders, delicate warm-toned neutrals, and refined serif typography. Every visual interaction evokes stillness, intimacy, and tactile prestige—eschewing aggressive saturated tones or heavy commercial clutter in favor of museum-grade presentation.

## Colors

The palette revolves around warm, natural light and softly polished metals, evoking hand-hammered rose gold, natural ivory pearls, and espresso silk display mats.

- **Primary (`#B77B70`)**: A desaturated blush rose gold accent, utilized sparingly for focal actions, active states, and precious interactive accents.
- **Secondary (`#E9D8C8`)**: Champagne beige providing warmth to secondary surfaces, subtle hover treatments, and soft contrast panels.
- **Tertiary / Base (`#FAF7F2`)**: Warm ivory foundation serving as the dominant background tone across all layouts, softening the harshness of pure white.
- **Neutral Primary (`#2B211E`)**: Deep espresso brown replacing harsh digital blacks for headlines, high-contrast borders, and primary copy.
- **Neutral Muted (`#7A6E68`)**: Soft taupe for metadata, secondary descriptions, and understated hints.
- **Borders & Dividers (`#E4DAD3`)**: Muted champagne hairline dividers that demarcate space without visual weight.
- **Surface Elevation (`#FDFCF9`)**: Tinted ivory card surface providing slight tonal separation from the primary canvas.

## Typography

The typographic hierarchy pairs the classical literary presence of EB Garamond with the understated, modern clarity of Plus Jakarta Sans.

- **Headlines (EB Garamond)**: Expressed with lightness and breath. It avoids heavy weights, prioritizing natural proportions, open kerning, and generous leading that emulate high-end architectural publications.
- **Body & Captions (Plus Jakarta Sans)**: Balanced, neutral, and highly legible. Body weights remain light to regular, preserving an airy, modern cadence that complements the classical display serif.
- **Labels & Microcopy**: Formatted in wide-tracked uppercase to establish clear functional anchors and product category indicators.

## Layout & Spacing

The layout is built upon an architectural grid designed to breathe:

- **Desktop (1200px+)**: 12-column grid, 64px (`margin`) outer boundaries, 32px (`gutter`) between columns. Maximum container width capped at 1360px to maintain editorial tension.
- **Tablet (768px - 1199px)**: 8-column grid, 32px outer canvas margins, 24px gutters.
- **Mobile (< 768px)**: 4-column grid, 20px outer canvas margins, 16px gutters.

Vertical rhythm relies on intentional negative space. Sections are delineated by abundant vertical clearance rather than aggressive background fills or heavy borders.

## Elevation & Depth

Visual hierarchy uses subtle surface shifts and diffused ambient light:

- **Surface Tiers**: Base pages rest on `#FAF7F2` (Warm Ivory). Cards, elevated sheets, and panels use `#FDFCF9` to produce a gentle, tactile lift.
- **Ambient Illumination**: Pure black shadows are strictly avoided. Depth is produced using low-opacity, warm espresso tints:
  - *Resting Card*: `0 2px 12px -2px rgba(43, 33, 30, 0.03)`
  - *Hover Elevation*: `0 12px 32px -4px rgba(43, 33, 30, 0.06)`
  - *Floating Dialog / Modal*: `0 24px 48px -12px rgba(43, 33, 30, 0.08)`
- **Structural Lines**: 1px borders colored in `#E4DAD3` define silhouettes cleanly without producing harsh visual containers.

## Shapes

The design system maintains a refined, tailored silhouette with Soft roundedness (Level 1):

- Standard components (cards, text fields, menu sheets) utilize a subtle 4px (`0.25rem`) corner radius, avoiding sterile sharpness while preserving precision.
- Buttons and chips can adapt between minimal soft rounding (4px) and complete capsule pill profiles (9999px) for jewelry tags and badges.
- Imagery remains rectangular with minimal corner rounding (4px) to honour gemstone geometry and atelier craftsmanship.

## Components

### Buttons
- **Primary**: Solid `#2B211E` background, `#FAF7F2` text, 4px border radius. Padding: 12px 28px. Font: `label-lg`. Subtle hover shift to `#B77B70` with a smooth 300ms transition.
- **Secondary (Outline)**: 1px border in `#2B211E`, transparent background, `#2B211E` text. Hover state gently fills with `#E9D8C8` at 20% opacity.
- **Tertiary / Text**: Unbordered, underlined with a 1px offset accent in `#B77B70`, tracked uppercase.

### Cards (Editorial Jewellery Card)
- **Container**: Background `#FDFCF9`, 1px border in `#E4DAD3`, 4px border radius.
- **Image Aspect**: 4:5 or 1:1 portrait ratio with generous 16px internal padding framing the product.
- **Details**: Centered typographic stack: Category (`label-sm`, `#7A6E68`), Title (`headline-sm`, `#2B211E`), Price/Karat (`body-sm`, `#B77B70`).

### Input Fields & Selectors
- **Surface**: Background `#FAF7F2`, 1px border in `#E4DAD3`. 4px radius. Height: 48px.
- **Text**: `body-md` in `#2B211E`. Placeholder in `#7A6E68`.
- **Focus**: Border shifts to `#B77B70` with no external glow ring, maintaining crisp minimalism.

### Chips & Badges
- **Pill Shape**: Height 24px, 9999px border radius, padding 2px 12px.
- **Tonal Palette**: Background `#E9D8C8` with `#2B211E` text for material highlights (e.g., "18K ROSE GOLD", "CERTIFIED NATURAL").

### Lists & Accordions
- **Dividers**: 1px solid hairline `#E4DAD3`.
- **Trigger**: `headline-sm` with a thin, bespoke plus/minus icon rendered at 1px stroke weight.

### Custom Atelier Components
- **Metal / Gemstone Selector**: 28px circular swatches wrapped in a 1px hairline ring with 3px clearance, indicating diamond grade and gold alloy options.
- **Provenance Monograph**: Full-bleed quote callout utilizing `headline-md` centered over `#FAF7F2` with subtle rose gold quotation glyphs.